﻿using Stock_System.Busines_Layer;
using Stock_System.Data_Layer;
using System;
using System.Windows.Forms;
namespace Stock_System.UI_Layer
{
    public partial class Company : Form
    {
       DCompany dCompany;
        BCompany iCompany;
        public static int insertUpdateFlag=0;
        //flag =1 insert 
        //flag =2 update 
        /// </summary>
        public Company()
        {
            InitializeComponent();

            iCompany = new BCompany(new DCompany());
          
        }
       

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtAdd.Clear();
            txtCode.Clear();
            txtContact.Clear();
            txtName.Clear();
         
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            insertUpdateFlag = 1;
            if (txtAdd.Text == String.Empty)
            { 
              MessageBox.Show("Please add the data in Address section", "Chasies Automobile", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAdd.Focus(); 
                return; 
            }
           
            
           
             dCompany = new DCompany();  
           

            dCompany.Com_Add =txtAdd.Text;
            dCompany.Com_name = txtName.Text;
            dCompany.Com_code = txtCode.Text;
            dCompany.Com_Contact = txtContact.Text;

           
            iCompany.insertdata(dCompany);
            MessageBox.Show("Data Saved Succefully","Manufacturing Company",MessageBoxButtons.OK, MessageBoxIcon.Information);
            ShowData(); 
        
        }


        public void ShowData()
        {
            
            DGCompany.DataSource = iCompany.getAllCompanyData(); 
        
        }

        private void Company_Load(object sender, EventArgs e)
        {
            ShowData(); 
        }

        private void Search_Click(object sender, EventArgs e)
        {
            
            dCompany = new DCompany();
            dCompany.Com_name = txtSearch.Text;  
           DGCompany.DataSource = iCompany.getSearchData(dCompany);
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            insertUpdateFlag = 2; 
            dCompany = new DCompany();


            dCompany.Com_Add = txtAdd.Text;
            dCompany.Com_name = txtName.Text;
            dCompany.Com_code = txtCode.Text;
            dCompany.Com_Contact = txtContact.Text;


            iCompany.insertdata(dCompany);
            MessageBox.Show("Data Updated  Succefully", "Manufacturing Company", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ShowData();
        }

        private void DGCompany_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           // txtCode.Text = Convert.ToString(DGCompany.Rows[e.RowIndex].Cells[1].Value); 
        }

        private void DGCompany_MouseEnter(object sender, EventArgs e)
        {
           
          //  txtCode.Text = Convert.ToString(DGCompany.Rows[].Cells[1].Value);
        }

        private void DGCompany_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtCode.Text = Convert.ToString(DGCompany.Rows[e.RowIndex].Cells[1].Value);
            txtName.Text = Convert.ToString(DGCompany.Rows[e.RowIndex].Cells[2].Value);
            txtAdd.Text = Convert.ToString(DGCompany.Rows[e.RowIndex].Cells[3].Value);
            txtContact.Text= Convert.ToString(DGCompany.Rows[e.RowIndex].Cells[4].Value);
        }
    }
}
