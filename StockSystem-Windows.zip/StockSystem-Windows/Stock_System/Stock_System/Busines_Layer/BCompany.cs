﻿using Stock_System.Data_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Stock_System.Busines_Layer.Comman;
namespace Stock_System.Busines_Layer
{
    internal class BCompany : ICompany 
    {

        DCompany DataAccess;
        BCompany _BCompany;
        public BCompany(DCompany dCompany)
        {
            DataAccess = dCompany;
            DataAccess = new DCompany();
        }

        public BCompany()
        {
            _BCompany = new BCompany();
           
        
        }
        
        

        public DataTable getAllCompanyData()
        {
           
            DataTable getData = CommanDBOperatoins.getAllData("Company_getAllData");
            return getData;
          
        }

        public DataTable getSearchData(DCompany dCompany)
        {
            DataTable dataTable= new DataTable();
            SqlParameter[] parameter = new SqlParameter[1];
            parameter[0] = new SqlParameter("@SearchData", dCompany.Com_name);
            dataTable = CommanDBOperatoins.getQueryData( parameter, "Company_getSearchData");
                return dataTable; 

        }

        public void insertdata(DCompany dCompany)
        {

            SqlParameter[] parameter = new SqlParameter[9];
            parameter[0] = new SqlParameter("@Com_Code", dCompany.Com_code);
            parameter[1] = new SqlParameter("@Com_Name", dCompany.Com_name);
            parameter[2] = new SqlParameter("@Com_Add", dCompany.Com_Add);
            parameter[3] = new SqlParameter("@Com_Contact", dCompany.Com_Contact);
            parameter[4] = new SqlParameter("@Created_ID", 1);
            parameter[5] = new SqlParameter("@Create_Date", System.DateTime.Now);
            parameter[6] = new SqlParameter("@Updated_ID", 1);
            parameter[7] = new SqlParameter("@Updated_Date", System.DateTime.Now);
            if (Stock_System.UI_Layer.Company.insertUpdateFlag == 1)
            {
                parameter[8] = new SqlParameter("@Operation", 1);
            }
            if (Stock_System.UI_Layer.Company.insertUpdateFlag == 2)
            {
                parameter[8] = new SqlParameter("@Operation", 2);
            }
            CommanDBOperatoins.insertdata(parameter, "UD_Company_InsertUpdate");

        }

     
          
        
        
    }
}
