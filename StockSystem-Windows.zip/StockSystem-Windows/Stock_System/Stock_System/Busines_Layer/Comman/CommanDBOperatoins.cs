﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
 

namespace Stock_System.Busines_Layer.Comman
{
    public static class CommanDBOperatoins
    {

        public static void insertdata(SqlParameter[] parameter, string procedureName)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["StockSystemConnectionString"].ConnectionString;

            string connString = connectionString.ToString();

            
       
           SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString= ConfigurationManager.ConnectionStrings["StockSystemConnectionString"].ConnectionString;
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
           
            SqlCommand cmd = new SqlCommand(procedureName, sqlConnection);
            cmd.CommandType = CommandType.StoredProcedure;

            for (int i = 0; i < parameter.Length; i++)
            {
                cmd.Parameters.Add(parameter[i]);

            }

            cmd.ExecuteNonQuery();
            sqlConnection.Close();
        }

        public static DataTable getAllData(string ProcedureName)
        {
            DataTable dataTable = new DataTable();
            SqlConnection sqlConnection = new SqlConnection("Data Source=DESKTOP-SUC1VNM\\SQLEXPRESS;Initial Catalog=stockSystem;Integrated Security=True");
            sqlConnection.Open();
            SqlCommand cmd = new SqlCommand(ProcedureName, sqlConnection);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataTable);
            sqlConnection.Close();
            return dataTable;
            


        }

        public static DataTable getQueryData(SqlParameter[] parameter, string procedureName)
        {
            DataTable getAllData = new DataTable();
            SqlConnection sqlConnection = new SqlConnection("Data Source=DESKTOP-SUC1VNM\\SQLEXPRESS;Initial Catalog=stockSystem;Integrated Security=True");
            sqlConnection.Open();
            SqlCommand cmd = new SqlCommand(procedureName, sqlConnection);
            cmd.CommandType = CommandType.StoredProcedure;

            for (int i = 0; i < parameter.Length; i++)
            {
                cmd.Parameters.Add(parameter[i]);

            }
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(getAllData);
            sqlConnection.Close();
            return getAllData;




        }
    }
}