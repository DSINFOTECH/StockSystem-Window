﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock_System.Busines_Layer
{
    public class EmployeeBusinessLogic
    {
        IEmployeeDataAccess _dataAccess;

        public EmployeeBusinessLogic(IEmployeeDataAccess empDataAccess)
        {
            _dataAccess = empDataAccess;
        }

        public EmployeeBusinessLogic()
        {
            _dataAccess = new EmployeeDataAccess();
        }

        public string ProcessEmployeeData(int id)
        {
            return _dataAccess.GetEmployeeName(id);
        }
    }

    public interface IEmployeeDataAccess
    {
        string GetEmployeeName(int id);
    }

    public class EmployeeDataAccess : IEmployeeDataAccess
    {
        public EmployeeDataAccess()
        {
            //
        }

        public string GetEmployeeName(int id)
        {
            //fetch the employee name from the database        
            return "Employee Name: John";
        }
    }

    public class EmployeeService
    {
        EmployeeBusinessLogic _empBL;

        public EmployeeService()
        {
            _empBL = new EmployeeBusinessLogic(new EmployeeDataAccess());
        }

        public string GetEmployeeName(int id)
        {
            return _empBL.ProcessEmployeeData(id);
        }

    }
}
