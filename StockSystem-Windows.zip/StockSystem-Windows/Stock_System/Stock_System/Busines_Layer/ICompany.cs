﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Stock_System.Data_Layer;
using System.Data;
namespace Stock_System.Busines_Layer
{
    internal interface ICompany
    {
         void insertdata(DCompany dCompany);
         DataTable getAllCompanyData();

        DataTable getSearchData(DCompany dCompany); 


    }
}
