﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock_System.Data_Layer
{
    public class DCompany
    {
      public   int Com_ID { get; set; }
        public string Com_code { get; set; }
        public string Com_name { get; set; }
        public string Com_Add;
        public string Com_Contact;
        public int Created_ID;
        public DateTime Created_DateTime;
        public int Updated_ID;
        public  DateTime Updated_Date;

       

    }
}
